﻿using System;
using System.Windows.Forms;
using IlluminaGenerateJSONDll;

namespace IlluminaSampleApp
{
    public partial class Form1 : Form
    {
        #region Member variables

        private bool _loginSuccess;
        private bool _isSingleReport = true;
        GenerateJSON json = new GenerateJSON();
        string _fileurl;

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="Form1"/> class.
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            _loginSuccess = false;
            singleReport.Checked = true;
            lblStatus.Text = string.Empty;
        }

        #region Methods

        /// <summary>
        /// Handles the Click event of the Login button.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void btnLogin_Click(object sender, EventArgs e)
        {
            _loginSuccess = json.Login(textUserID.Text, textPassword.Text);
            if (_loginSuccess)
            {
                lblStatus.Text = "Illumina login SUCCESS...";
                btnReport.Enabled = true;
            }
        }

        /// <summary>
        /// Handles the Click event of the generate report button.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void btnReport_Click(object sender, EventArgs e)
        {
            if (_loginSuccess)
            {
                webBrowser1.Navigate("about:blank");
                textBox1.Text = "";
                lblStatus.Text = "Downloding HTML report ...";
                bool downloadSuccess = json.DownloadReport(textAnalysisID.Text, textReportID.Text, textHTMLFolder.Text, _isSingleReport, out _fileurl);

                lblStatus.Text = "HTML report downloaded and saved as " + _fileurl + ". Trying to open the HTML report and it will take a few seconds... Please wait.";

                if (downloadSuccess)
                {
                    string jsonoutput = json.GenerateJSONOutput();

                    webBrowser1.ScriptErrorsSuppressed = true;
                    webBrowser1.Navigate(_fileurl);

                    textBox1.Text = jsonoutput;
                    lblStatus.Text = "JSON file is generated in the same folder ( " + textHTMLFolder.Text + ") of HTML file.";
                }
                else
                {
                    lblStatus.Text = "Specified Analysis report is not yet available at Illumina.";
                    MessageBox.Show("Specified Analysis report is not yet available at Illumina.", "Illumina");
                }
            }
            else
            {
                lblStatus.Text = "Illumina login failed";
                MessageBox.Show("Illumina login failed", "Illumina");
            }
        }

        /// <summary>
        /// Handles the CheckedChanged event of the single report control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void singleReport_CheckedChanged(object sender, EventArgs e)
        {
            _isSingleReport = true;
        }

        /// <summary>
        /// Handles the CheckedChanged event of the summary report control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void summaryReport_CheckedChanged(object sender, EventArgs e)
        {
            _isSingleReport = false;
        }

        #endregion
    }
}


