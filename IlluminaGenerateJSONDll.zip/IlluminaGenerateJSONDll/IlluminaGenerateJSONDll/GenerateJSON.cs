﻿using HtmlAgilityPack;
using Newtonsoft.Json.Linq;
using OpenQA.Selenium.PhantomJS;
using OpenQA.Selenium.Support.UI;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using AgilityDocument = HtmlAgilityPack.HtmlDocument;

namespace IlluminaGenerateJSONDll
{
    /// <summary>
    /// Class to download webpage content and GenerateJSON from html.
    /// </summary>
    public class GenerateJSON
    {
        #region Member variables

        private HttpClient _httpClient = new HttpClient();
        string _analysisId;
        string _reportId;
        string _fileUrl;
        string _htmlFolder;
        private bool _loginSuccess;
        private bool _isSingleReport;
        string _truseqAampliconVariantsCsv;
        string _ampliconCoverageChartCsv;
        const string ILLUMINA_LOGIN_URL = "https://basespace.illumina.com/appsession/details?token=";
        const string VARIANTS_TABLE_FILE_NAME = "_truseq - amplicon - variants";
        const string AMPLICON_COVERAGE_FILE_NAME = "_amplicon - coverage";
        const string URL_RESPONSE = "Report is being generated. Please wait...";
        const string DATATABLES_TABLE_0_LENGTH = "DataTables_Table_0_length";
        const string DATATABLES_TABLE_1_LENGTH = "DataTables_Table_1_length";
        const string DATATABLES_TABLE_2_LENGTH = "DataTables_Table_2_length";
        const string DATATABLES_TABLE_3_LENGTH = "DataTables_Table_3_length";
        const string DATATABLES_TABLE_4_LENGTH = "DataTables_Table_4_length";
        const string DATATABLES_TABLE_5_LENGTH = "DataTables_Table_5_length";
        const string JSON_FILE_NAME = "Output.json";
        const string TABLE_NODE = "//table";
        string _jsonOutput;

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="GenerateJSON"/> class.
        /// </summary>
        public GenerateJSON()
        {
        }

        #endregion

        #region Methods

        /// <summary>
        /// Logins to the Illumina.
        /// </summary>
        /// <param name="username">The username.</param>
        /// <param name="password">The password.</param>
        public bool Login(string username, string password)
        {
            password = WebUtility.UrlEncode(password);

            String strPayload = "{\"username\":\"" + username + "\",\"password\":\"" + password +
                "\",\"domain\":\"basespace\",\"rURL\":\"https://basespace.illumina.com\",\"clientVars\":\"xxaHR0cHM6Ly9iYXNlc3BhY2UuaWxsdW1pbmEuY29tLw\",\"originPlatformUrl\":\"undefined\",\"clientId\":\"basespace\",\"deviceType\":\"\"}";
            var content = new StringContent(strPayload, Encoding.UTF8, "application/json");

            var response = _httpClient.PostAsync("https://login.illumina.com/platform-services-manager/auth/authenticate", content).Result;

            if (response.IsSuccessStatusCode)
            {
                _loginSuccess = true;
            }
            else
            {
                _loginSuccess = false;
            }

            return _loginSuccess;
        }

        /// <summary>
        /// Downloads the report.
        /// </summary>
        /// <param name="analysisId">The analysis identifier.</param>
        /// <param name="reportId">The report identifier.</param>
        public bool DownloadReport(string analysisId, string reportId, string htmlFolder, bool reportType, out string fileUrl)
        {
            _isSingleReport = reportType;
            _htmlFolder     = htmlFolder;
            _analysisId     = analysisId;
            _reportId       = reportId;
            fileUrl         = string.Empty;

            bool isDownloadScuccess = true;

            if (!Directory.Exists(htmlFolder))
            Directory.CreateDirectory(htmlFolder);

            if (_loginSuccess)
            {
                string AnalysisID = analysisId;
                string ReportID   = reportId;
                if (ReportID == string.Empty) ReportID = "0";

                string GetURL = ILLUMINA_LOGIN_URL + AnalysisID + "&appResultId=" + ReportID;
                var urlResponse = _httpClient.GetAsync(GetURL).Result;
                _fileUrl = string.Empty;
                if (urlResponse.IsSuccessStatusCode)
                {
                    var contents = urlResponse.Content.ReadAsStringAsync().Result;
                    if (!string.Equals( contents,URL_RESPONSE))
                    {
                        string HTMLfileName = "\\" + AnalysisID + "_" + ReportID + ".html";
                        File.WriteAllText(_htmlFolder + HTMLfileName, contents);
                        _fileUrl = (_htmlFolder + HTMLfileName);
                        fileUrl = _fileUrl;
                    }
                    else
                    {
                        isDownloadScuccess = false;
                    }
                }
            }

            isDownloadScuccess = ExecutePageScriptAndDownload();
            return isDownloadScuccess;
        }

        /// <summary>
        /// Outputs the json.
        /// </summary>
        /// <param name="JSONOutput">The json output.</param>
        public string GenerateJSONOutput()
        {
            if (_jsonOutput != string.Empty)
            {
                File.WriteAllText(_htmlFolder + "\\" + _analysisId + "_"  +_reportId + "_" + JSON_FILE_NAME, _jsonOutput);
            }
            return _jsonOutput;
        }

        /// <summary>
        /// Validates type of the reoprt.
        /// </summary>
        /// <param name="formattedSource">The formatted source.</param>
        private bool ValidateReoprtType(string formattedSource)
        {
            bool isValidReport = true;

            if (_isSingleReport)
            {
                if (!(formattedSource.Contains("var variantTableHref =")))
                {
                    isValidReport = false;
                }
            }
            else
            {
                if (!(formattedSource.Contains("DataTables_Table_0_length")))
                {
                    isValidReport = false;
                }
            }

            return isValidReport;
        }

        /// <summary>
        /// Save html output of the page after execution of the page's javascript.
        /// </summary>
        private bool ExecutePageScript()
        {
            bool isScriptExecuted = true;
            var options = new PhantomJSOptions();
            options.AddAdditionalCapability("IsJavaScriptEnabled", true);
            var service = PhantomJSDriverService.CreateDefaultService();
            service.SslProtocol = "tlsv1";
            service.HideCommandPromptWindow = true;
            var driver = new PhantomJSDriver(service);
            if (_isSingleReport)
            {
                string appendTovariantsTableUrl = "file:///";
                driver.Navigate().GoToUrl(appendTovariantsTableUrl + _fileUrl);
            }
            else
            {
                driver.Url = _fileUrl;
            }

            var source = driver.PageSource;
            string pageSource = source;
            string formattedSource = pageSource.Replace("\r\n", "");
            File.WriteAllText(_fileUrl, formattedSource);

            bool isValidReport = ValidateReoprtType(formattedSource);
            if (!isValidReport)
            {
                return false;
            }

            try
            {
                if (!_isSingleReport)
                {
                    var pathElement = driver.FindElementByName(DATATABLES_TABLE_0_LENGTH);
                    var selectedElement = new SelectElement(pathElement);
                    selectedElement.SelectByValue("-1");

                    pathElement = driver.FindElementByName(DATATABLES_TABLE_1_LENGTH);
                    selectedElement = new SelectElement(pathElement);
                    selectedElement.SelectByValue("-1");

                    pathElement = driver.FindElementByName(DATATABLES_TABLE_2_LENGTH);
                    selectedElement = new SelectElement(pathElement);
                    selectedElement.SelectByValue("-1");

                    pathElement = driver.FindElementByName(DATATABLES_TABLE_3_LENGTH);
                    selectedElement = new SelectElement(pathElement);
                    selectedElement.SelectByValue("-1");

                    pathElement = driver.FindElementByName(DATATABLES_TABLE_4_LENGTH);
                    selectedElement = new SelectElement(pathElement);
                    selectedElement.SelectByValue("-1");

                    pathElement = driver.FindElementByName(DATATABLES_TABLE_5_LENGTH);
                    selectedElement = new SelectElement(pathElement);
                    selectedElement.SelectByValue("-1");

                    source = driver.PageSource;

                    string summaryPageSource = source;
                    string formattedPageSource = summaryPageSource.Replace("\r\n", "");
                    File.WriteAllText(_fileUrl, formattedPageSource);
                }
                driver.Quit();
            }

            catch (Exception ex)
            {
                isScriptExecuted= false;
            }

            return isScriptExecuted;
        }

        /// <summary>
        /// Finds the variants file name from HTML.
        /// </summary>
        /// <param name="strHTMLFileName">Name of the HTML file.</param>
        private string FindVariantsFileNameFromHTML(string strHTMLFileName)
        {
            string strVariantsFileName = "";

            AgilityDocument doc = new AgilityDocument();
            doc.Load(strHTMLFileName);
            string sourceHTML = (doc.DocumentNode.InnerHtml);
            int start = sourceHTML.IndexOf(@"var variantTableHref =");
            int startLoc = sourceHTML.IndexOf("\"", start);
            int endloc = sourceHTML.IndexOf("\"", startLoc + 1);
            strVariantsFileName = sourceHTML.Substring(startLoc + 1, endloc - startLoc);
            return strVariantsFileName.Remove(strVariantsFileName.Length - 1);
        }

        /// <summary>
        /// Finds the chart file name from HTML.
        /// </summary>
        /// <param name="strHTMLFileName">Name of the HTML file.</param>
        private string FindChartFileNameFromHTML(string strHTMLFileName)
        {
            string strChartDataFileName = "";
            AgilityDocument doc = new AgilityDocument();
            doc.Load(strHTMLFileName);
            string sourceHTML = (doc.DocumentNode.InnerHtml);
            int start = sourceHTML.IndexOf(@"ampliconcoverageplot");
            string ssubstring = "href=\"";
            int startLoc = sourceHTML.IndexOf(ssubstring, start);
            startLoc = startLoc + ssubstring.Length;
            int endloc = sourceHTML.IndexOf("\"", startLoc);
            strChartDataFileName = sourceHTML.Substring(startLoc, endloc - startLoc);
            return strChartDataFileName;
        }

        /// <summary>
        /// Download the variants table and amplicon coverage plot.
        /// </summary>
        /// <param name="url">The URL.</param>
        /// <param name="filename">The filename.</param>
        private string DownloadVariantsTableAndAmpliconCoveragePlot(string url, string filename, bool isTextFile = false)
        {
            string path = "";
            var response = _httpClient.GetAsync(url).Result;
            if (response.IsSuccessStatusCode)
            {
                var contents = response.Content.ReadAsStringAsync().Result;
                if (!string.Equals(contents, URL_RESPONSE))
                {
                    if (isTextFile)
                    {
                        contents = contents.Replace("\t", ",");
                    }
                    string HTMLfileName = filename;
                    File.WriteAllText(_htmlFolder + HTMLfileName, contents);
                    path = (_htmlFolder + HTMLfileName);
                    return path;
                }
            }
            return path;
        }

        /// <summary>
        /// Executes the page script and download.
        /// </summary>
        private bool ExecutePageScriptAndDownload()
        {
            if (!string.IsNullOrEmpty(_fileUrl))
            {
                // To execute javascript of the page
                bool validReport = ExecutePageScript();

                if (!validReport)
                {
                    return false;
                }

                if (_isSingleReport)
                {
                    string HTMLvariantsfileName = "\\" + _analysisId + "_" + _reportId + VARIANTS_TABLE_FILE_NAME + ".csv";
                    string HTMLChartfileName = "\\" + _analysisId + "_" + _reportId + AMPLICON_COVERAGE_FILE_NAME + ".csv";

                    string vatiantsTableUrl = FindVariantsFileNameFromHTML(_fileUrl);
                    string ampliconChart = FindChartFileNameFromHTML(_fileUrl);

                    _truseqAampliconVariantsCsv = DownloadVariantsTableAndAmpliconCoveragePlot(vatiantsTableUrl, HTMLvariantsfileName, true);
                    _ampliconCoverageChartCsv = DownloadVariantsTableAndAmpliconCoveragePlot(ampliconChart, HTMLChartfileName);
                }

                _jsonOutput = GenerateJSONFromHTML(_fileUrl);

            }
            else
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Generates the json from HTML.
        /// </summary>
        /// <param name="strHTMLFileName">Name of the HTML file.</param>
        private string GenerateJSONFromHTML(string strHTMLFileName)
        {
            string strJSONOutput = "";
            try
            {
                AgilityDocument doc = new AgilityDocument();
                doc.Load(strHTMLFileName);
                JObject jsonObj = new JObject();
                var tables = _isSingleReport ? doc.DocumentNode.SelectNodes(TABLE_NODE).Skip(1) : doc.DocumentNode.SelectNodes(TABLE_NODE);
                bool bToolTipTable = true;
                bool variantsTableCanbePopulated = false;
                string variantsTableHeading = "";
                bool chartTableCanbePopulated = false;
                string chartTableHeading = "";

                HtmlNode previousTableHead = doc.DocumentNode.SelectSingleNode(TABLE_NODE);
                var headingNode = doc.DocumentNode.SelectSingleNode(TABLE_NODE);

                foreach (HtmlNode table in tables)
                {
                    string s = table.GetAttributeValue("class", "");
                    var heading = string.Empty;
                    HtmlNodeCollection keys = table.SelectNodes(".//th");
                    HtmlNodeCollection values = table.SelectNodes(".//td");

                    if (bToolTipTable)
                    {
                        if (_isSingleReport)
                        {
                            headingNode = table.ParentNode.ParentNode.ParentNode.ParentNode.ParentNode;
                            if (headingNode.FirstChild != null)
                            {
                                heading = headingNode.FirstChild.InnerText + " Tool Tip";
                                previousTableHead = headingNode;

                                //Chart table can be populated
                                if (table.ParentNode.ParentNode.ParentNode.Id == "ampliconcoverageplot")
                                {
                                    chartTableCanbePopulated = true;
                                    chartTableHeading = headingNode.FirstChild.InnerText;
                                }

                                //Variants table handling
                                if (headingNode.Id == "variants-table-header")
                                {
                                    variantsTableCanbePopulated = true;
                                    variantsTableHeading = headingNode.FirstChild.InnerText;
                                    bToolTipTable = !bToolTipTable; // We dont have table for next variants table.
                                }
                            }
                        }

                        else
                        {
                            headingNode = table.ParentNode.ParentNode.ParentNode.ParentNode.PreviousSibling;
                            heading = headingNode.InnerText + " Tool Tip";
                            previousTableHead = headingNode;
                        }
                    }
                    else
                    {
                        if (!_isSingleReport)
                        {
                            headingNode = previousTableHead;
                            heading = headingNode.InnerText;
                        }
                        else
                        {
                            headingNode = previousTableHead;
                            if (headingNode.FirstChild != null)
                            {
                                heading = headingNode.FirstChild.InnerText;
                            }
                        }
                    }

                    bToolTipTable = !bToolTipTable;


                    if (keys != null && keys.Count > 0)
                    {
                        if (values.Count > keys.Count)
                        {
                            JArray jsonArray = new JArray();
                            int vIndex = 0;

                            for (int i = 0; i < values.Count / keys.Count; i++)
                            {
                                var obj = CreateJsonObject(keys, values, vIndex);
                                vIndex += keys.Count;
                                jsonArray.Add(obj);
                            }
                            jsonObj.Add(heading, jsonArray);
                        }
                        else
                        {
                            var obj = CreateJsonObject(keys, values);
                            jsonObj.Add(heading, obj);
                        }
                    }
                }

                var jsonHeadNode = doc.DocumentNode.SelectSingleNode("//table");

                var jobj = new JObject
                    {
                        {
                            jsonHeadNode.InnerText,
                            jsonObj
                        }
                    };

                if (!_isSingleReport)
                {
                    jobj = new JObject
                    {
                        {
                            jsonHeadNode.ParentNode.ParentNode.ParentNode.ParentNode.PreviousSibling.ParentNode.PreviousSibling.ParentNode.PreviousSibling.PreviousSibling.InnerText,
                            jsonObj
                        }
                    };
                }

                strJSONOutput = jobj.ToString();
            }

            catch (Exception ex)
            {
                // MessageBox.Show(ex.ToString());
            }

            return strJSONOutput;
        }

        /// <summary>
        /// Creates the json object.
        /// </summary>
        /// <param name="keys">The keys.</param>
        /// <param name="values">The values.</param>
        /// <param name="vIndex">Index</param>
        private static JObject CreateJsonObject(HtmlNodeCollection keys, HtmlNodeCollection values, int vIndex = 0)
        {
            JObject obj = new JObject();
            for (int j = 0; j < keys.Count; j++)
            {
                JProperty property = new JProperty(keys[j].InnerText, values[vIndex].InnerText);
                obj.Add(property);
                vIndex++;
            }
            return obj;
        }

        #endregion
    }
}
